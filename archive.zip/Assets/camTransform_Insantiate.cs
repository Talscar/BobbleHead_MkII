﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class camTransform_Insantiate : MonoBehaviour {

//Work's in Editor mode.
//Press a Key, insantiate a new transform in numerical order with the numerical name.
//Press Alt and a Key to setup a placeholder prefab which is seen in the Editor but not playmode.

//For testing purposes Shift + Clicking a Transform will move the Camera display 2 (NOT MAIN) to these coordinates for test viewing!
}
